document.addEventListener("DOMContentLoaded", () => {
  const splash = document.getElementById("splash-screen");
  const app = document.getElementById("app");

  setTimeout(() => {
    splash.classList.add("hidden");
    app.classList.remove("hidden");
  }, 5000);

  const toggle = document.getElementById("theme-toggle");
  toggle.addEventListener("change", () => {
    document.body.classList.toggle("dark-mode");
    document.body.classList.toggle("light-mode");
  });
});

function loadComponent(name) {
  fetch(`components/${name}Control.html`)
    .then(res => res.text())
    .then(html => {
      document.getElementById("main-content").innerHTML = html;
    })
    .catch(err => {
      document.getElementById("main-content").innerHTML = "<p>Component not found.</p>";
    });
}